// 随机生成座右铭
const quotes = [
    "成功是一连串努力和坚持的结果。",
    "机会永远留给那些有准备的人。",
    "别让昨天的悔恨，成为明天的遗憾。",
    "行动是实现梦想的桥梁。",
    "不要等待机会，而要创造机会。",
    "改变世界，从改变自己开始。",
    "勇往直前，无所畏惧。",
    "相信自己，你能做到。",
    "不要停下脚步，追逐梦想的道路上。",
    "只有拥有梦想，才有实现梦想的力量。",
    "大作业好难写"
];

function generateQuote() {
    const randomIndex = Math.floor(Math.random() * quotes.length);
    const quoteElement = document.getElementById("quote");
    quoteElement.textContent = quotes[randomIndex];
}

generateQuote();  
//悬停事件
const buttons = document.querySelectorAll('.popup-button');

buttons.forEach(button => {
    button.addEventListener('mouseover', () => {
        const tooltip = button.getAttribute('data-tooltip');
        button.setAttribute('title', tooltip);
    });

    button.addEventListener('mouseout', () => {
        button.removeAttribute('title');
    });
});

// 个人简介输入
function saveContent() {
    var content = document.getElementById("my").innerText;
    localStorage.setItem("savedContent", content);
    alert("内容已保存！");
}

window.onload = function() {
    var savedContent = localStorage.getItem("savedContent");
    if (savedContent) {
        document.getElementById("my").innerText = savedContent;
    }
};

//关闭广告
function hideButton(buttonId, buttonWrapper) {
    var button = document.getElementById(buttonId);
    button.style.display = "none";
    buttonWrapper.remove();
}







