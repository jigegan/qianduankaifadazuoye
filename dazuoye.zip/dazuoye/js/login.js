//连接服务器
const express = require('express');
const app = express();
const mysql = require('mysql');
const pool = mysql.createPool({
  host: '127.0.0.1',
  port: '3306',
  user: 'newuser',
  password: 'xxxxxx',
  database: 'login',
  charset:'utf8'
});

// 解析请求体中的参数
app.use(express.urlencoded({ extended: false }));

// 处理登录请求
app.post('/login', (req, res) => {
  var username = req.body.username;
  var password = req.body.password;

  // 在这里使用连接池执行数据库查询操作
  pool.query('SELECT * FROM users WHERE username = ? AND password = ?', [username, password], (error, results) => {
    if (error) {
      console.error('登录出错:', error);
      res.json({ success: false, message: '登录出错' });
    } else {
      if (results.length > 0) {
        res.json({ success: true, message: '登录成功' });
      } else {
        res.json({ success: false, message: '用户名或密码错误' });
      }
    }
  });
});

// 处理注册请求
app.post('/register', (req, res) => {
  var username = req.body.username;
  var password = req.body.password;

  // 在这里使用连接池执行数据库插入操作
  pool.query('INSERT INTO users (username, password) VALUES (?, ?)', [username, password], (error, results) => {
    if (error) {
      console.error('注册出错:', error);
      res.json({ success: false, message: '注册出错' });
    } else {
      res.json({ success: true, message: '注册成功' });
    }
  });
});

// 静态文件服务
app.use(express.static('./'));

// 启动服务器
app.listen(8080, () => {
  console.log('服务器已启动，监听端口8080');
});

/*检查登录是否合法*/
function checklogin() {
  var username = document.getElementById('myname').value;
  var pwd = document.getElementById('mypwd').value;

  if (username == '') {
    alert('用户名不能为空！');
    document.getElementById('myname').focus();
    return false;
  } else if (username.length < 5 || username.length > 20) {
    alert('用户名太短，应在5~20个字符之间！');
    document.getElementById('myname').focus();
    return false;
  }
  if (pwd == '') {
    alert('密码不能为空！');
    document.getElementById('mypwd').focus();
    return false;
  } else if (pwd.length < 6 || pwd.length > 20) {
    alert('密码太短，应在6~20个字符之间！');
    document.getElementById('mypwd').focus();
    return false;
  }

  // 发送登录请求
  axios
    .post('/login', { username: username, password: pwd })
    .then((response) => {
      // 处理服务器的响应数据
      var data = response.data;
      if (data.success) {
        alert('登录成功！');
        return true;
      } else {
        alert('登录失败：' + data.message);
      }
    })
    .catch((error) => {
      console.error('登录出错:', error);
    });
}

/*注册*/
function register() {
  var username = document.getElementById('regname').value;
  var pwd = document.getElementById('regpwd').value;
  var pwd2 = document.getElementById('repaetpwd').value;
  if (username == '') {
    alert('用户名不能为空！');
    document.getElementById('regname').focus();
    return false;
  } else if (username.length < 5 || username.length > 20) {
    alert('用户名太短，应在5~20个字符之间！');
    document.getElementById('regname').focus();
    return false;
  }
  if (pwd == '') {
    alert('密码不能为空！');
    document.getElementById('regpwd').focus();
    return false;
  } else if (pwd.length < 6 || pwd.length > 20) {
    alert('密码太短，应在6~20个字符之间！');
    document.getElementById('regpwd').focus();
    return false;
  } else if (pwd != pwd2) {
    alert('确认密码必须与密码保持一致');
    document.getElementById('regpwd').focus();
    return false;
  }

  // 发送注册请求
  axios
    .post('/register', { username: username, password: pwd })
    .then((response) => {
      // 处理服务器的响应数据
      var data = response.data;
      if (data.success) {
        alert('注册成功！');
        return true;
      } else {
        alert('注册失败：' + data.message);
      }
    })
    .catch((error) => {
      console.error('注册出错:', error);
    });
}


//显示不同窗口
function showRegisterForm() {
    const loginForm = document.querySelector('.login');
    const registerForm = document.querySelector('.register');

    loginForm.classList.remove('active');
    registerForm.classList.add('active');
}

function showLoginForm() {
    const loginForm = document.querySelector('.login');
    const registerForm = document.querySelector('.register');

    registerForm.classList.remove('active');
    loginForm.classList.add('active');
}


